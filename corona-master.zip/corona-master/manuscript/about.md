manuscript and all files, reuse permitted under GPL_v3 licence
